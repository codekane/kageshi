(function() {
  var kageshit = document.createElement('script');
  kageshit.type = 'text/javascript';
  //kageshit.async = true;
  kageshit.src = "https://gist.github.com/smokeyhere/904d94f0757774fc2255f038e97fa707.js";

  var tag = document.getElementsByTagName('script')[0];
  tag.parentNode.insertBefore(kageshit, tag);
})()

